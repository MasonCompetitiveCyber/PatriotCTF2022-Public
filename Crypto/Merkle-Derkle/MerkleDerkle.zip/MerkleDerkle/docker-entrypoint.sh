#!/bin/sh
exec python3 main.py