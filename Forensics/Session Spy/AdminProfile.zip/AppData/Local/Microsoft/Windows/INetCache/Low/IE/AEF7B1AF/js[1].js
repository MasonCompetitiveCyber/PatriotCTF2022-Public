(function() {
  var f = document.getElementsByTagName('script')[0],
      s = document.createElement('script');
  s.async = true;
  s.defer = true;
  s.src = 'https://jac.yahoosandbox.com/0.10.1/jac.js';
  f.parentNode.insertBefore(s, f);
})();
