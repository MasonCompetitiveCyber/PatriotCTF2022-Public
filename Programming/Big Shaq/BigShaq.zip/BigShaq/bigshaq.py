import random
import socketserver
from string import ascii_lowercase
from sympy import symbols, Eq, solve
from sympy.parsing.sympy_parser import parse_expr

from emojis import all_emojis

def solveable(lse):
    vars = iter(ascii_lowercase)
    eqs = {}
    mapping = {}
    main = lse.replace(" ", "").split("\n")
    n = len(main[0].split("=")[0].split("+"))

    for i in range(n):
        eq = main[i]
        answer = eq.split("=")[1]
        tokens = eq.split("=")[0].split("+")
        
        for token in tokens:
            token = token
            if token not in mapping.keys():
                mapping[token] = next(vars)

        sympy_eq = mapping[tokens[0]]
        for token in tokens[1:]:
            sympy_eq += " + " + mapping[token]

        eqs[i] = (sympy_eq, answer)

    syms = symbols(tuple(mapping.values()))

    solution = solve((Eq(parse_expr(eqs[0][0]), int(eqs[0][1])), Eq(parse_expr(eqs[1][0]), int(eqs[1][1])), Eq(parse_expr(eqs[2][0]), int(eqs[2][1])), Eq(parse_expr(eqs[3][0]), int(eqs[3][1])), Eq(parse_expr(eqs[4][0]), int(eqs[4][1]))), syms)
    
    return int(sum(solution.values()))


def create_sle():
    sle = ""
    vars = {}
    emoji_list = all_emojis
    for i in range(5):
        chosen = random.choice(emoji_list)
        vars[chosen] = random.randint(-69,69)
        emoji_list.remove(chosen)

    for var in vars.keys():
        solution = 0
        eq = ""
        eq += var
        solution += vars[var]
        for i in range(4):
            rand_var = random.choice(list(vars.keys()))
            solution += vars[rand_var]
            eq += " + " + rand_var
        
        eq += " = " + str(solution)
        sle += eq + "\n"

    try:
        sum = str(solveable(sle))
    except Exception as e:
        return create_sle()
    else:
        return sle,vars,sum


def check(req):
    input = req.recv(256)
    if input.decode() == vars:
        return True
    else:
        return False
        

class RequestHandler(socketserver.StreamRequestHandler):
    def handle(self):
        req = self.request
        req.settimeout(5)
        solved = True

        for i in range(5):
            req.sendall(f'Question {i+1}:\n'.encode())
            sle, vars, sum = create_sle()
            req.sendall(sle.encode())
            q = " + ".join(vars.keys()) + " = "
            req.sendall(b"\n" + q.encode())
            try:
                input = req.recv(256)
            except:
                req.sendall(b'\n\nToo slow!\n')
                solved = False
                break
            
            if input.decode() != sum:
                req.sendall(b'\nWrong!\n')
                solved = False
                break
            else:
                req.sendall(b'\nCorrect!\n')
        
        if solved:
            req.sendall(b'\nPCTF{2_plus_2_1s_4_m1nus_0n3_th4ts_3_qu1ck_m4ths}\n')


class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    pass


if __name__ == '__main__':
    host, port = 'localhost', 8000

    # sys.stderr.write('Listening {}:{}\n'.format(host, port))
    server = ThreadedTCPServer((host, port), RequestHandler)
    ThreadedTCPServer.allow_reuse_address = True
    ThreadedTCPServer.allow_reuse_port = True
    server.serve_forever()